package dev.lelonio.square.backend.lyrics

import android.icu.text.Transliterator

/**
 * A lyric in Latin letters, for reading a song along to in a script the
 * listener cannot read: Hindi, Korean, Arabic, Russian and the rest.
 *
 * The platform's own transliteration tables do the work, so it needs no network
 * and no key, and costs nothing until it is asked for. What comes back is a
 * reading aid and not a standard: long vowels and diacritics are dropped to
 * plain letters, and Hindi's silent a is written where it is not said.
 *
 * Two kinds of line are left alone, and come back empty so nothing is drawn
 * under them:
 *  - a line already in Latin letters, which has nothing to romanise;
 *  - a Japanese line with kanji in it. The tables read a kanji the Chinese way,
 *    which for a Japanese song is wrong, and a wrong reading is worse than
 *    none. Lines in kana alone are fine.
 */
object Romanize {

    private val transliterator: Transliterator? by lazy {
        runCatching { Transliterator.getInstance("Any-Latin; Latin-ASCII") }.getOrNull()
    }

    /** One reading per line of [texts], in the same order; empty where there is none to give. */
    fun lines(texts: List<String>): List<String> {
        val table = transliterator ?: return texts.map { "" }
        return texts.map { line ->
            if (!needsRomanizing(line)) {
                ""
            } else {
                val reading = runCatching { table.transliterate(line) }.getOrDefault("").trim()
                if (reading.isBlank() || reading.equals(line.trim(), ignoreCase = true)) "" else reading
            }
        }
    }

    private fun needsRomanizing(line: String): Boolean {
        if (line.isBlank()) return false
        var otherScript = false
        var han = false
        var kana = false
        for (ch in line) {
            when (Character.UnicodeScript.of(ch.code)) {
                Character.UnicodeScript.LATIN,
                Character.UnicodeScript.COMMON,
                Character.UnicodeScript.INHERITED,
                -> Unit

                Character.UnicodeScript.HAN -> {
                    han = true
                    otherScript = true
                }

                Character.UnicodeScript.HIRAGANA,
                Character.UnicodeScript.KATAKANA,
                -> {
                    kana = true
                    otherScript = true
                }

                else -> otherScript = true
            }
        }
        return otherScript && !(han && kana)
    }
}
