package dev.lelonio.square.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * The app's loading animation: a soft glass shape that turns on the spot while it
 * melts from one rounded form into the next (a circle, a rounded square, a
 * flower, a gear, a blob, fourteen in all), with a pale rim, a shine across it
 * and a little glow behind. It replaces the thin white line that used to go
 * round wherever something was loading.
 *
 * Every form is smooth: no corners, no points. It never travels; it turns about
 * its own centre.
 *
 * Drawn in a 300-unit square and scaled to whatever size it is given, so it is
 * the same picture at 16 dp in a button and at 52 dp in the middle of a page.
 */
@Composable
fun MorphLoader(modifier: Modifier = Modifier, size: Dp = 40.dp) {
    var now by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        val start = withFrameMillis { it }
        while (true) now = withFrameMillis { it } - start
    }

    // Reused every frame: nothing is allocated while it runs.
    val points = remember { FloatArray(POINTS * 2) }
    val body = remember { Path() }

    Canvas(modifier.size(size)) {
        val unit = this.size.minDimension / VIEW
        val centre = Offset(this.size.width / 2f, this.size.height / 2f)

        // Which two forms it is between, and how far.
        val local = now % LOOP
        val index = (local / STEP).toInt()
        val within = (local - index * STEP).toFloat()
        val next = (index + 1) % FORMS.size
        val t = smooth(within / MORPH)
        val from = FORMS[index]
        val to = FORMS[next]
        for (i in 0 until POINTS * 2) points[i] = from[i] + (to[i] - from[i]) * t

        curve(body, points, centre, unit)

        val spin = ((now * SPIN_PER_MS) % (2.0 * PI)).toFloat() * (180f / PI.toFloat())
        rotate(degrees = spin, pivot = centre) {
            val box = VIEW * unit
            val left = centre.x - box / 2f
            val top = centre.y - box / 2f

            // The glow: the same shape, wider and fainter, a few times over, in place of a blur.
            for (grow in GLOW_STEPS) {
                drawPath(
                    path = body,
                    color = GLOW.copy(alpha = GLOW_ALPHA),
                    style = Stroke(width = grow * unit, join = StrokeJoin.Round),
                )
            }
            drawPath(body, color = GLOW.copy(alpha = 0.18f))

            // Glass: the fill, then the rim.
            drawPath(
                path = body,
                brush = Brush.linearGradient(
                    0f to Color(0xFFA9D5FF).copy(alpha = 0.82f),
                    0.32f to Color(0xFF548ED2).copy(alpha = 0.60f),
                    0.72f to Color(0xFF5279B5).copy(alpha = 0.42f),
                    1f to Color(0xFFB8E1FF).copy(alpha = 0.68f),
                    start = Offset(left, top),
                    end = Offset(left + box, top + box),
                ),
            )
            drawPath(
                path = body,
                color = Color(0xFFE2F1FF).copy(alpha = 0.62f),
                style = Stroke(
                    width = max(2.2f * unit, 1f),
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round,
                ),
            )

            // The shine across it.
            drawPath(
                path = body,
                brush = Brush.linearGradient(
                    0f to Color.White.copy(alpha = 0.50f),
                    0.38f to Color.White.copy(alpha = 0.11f),
                    1f to Color.White.copy(alpha = 0f),
                    start = Offset(left + box * 0.1f, top),
                    end = Offset(left + box * 0.85f, top + box),
                ),
                alpha = 0.9f,
            )

            // A finer line just inside the rim.
            scale(scale = INNER, pivot = centre) {
                drawPath(
                    path = body,
                    color = Color.White.copy(alpha = 0.27f),
                    style = Stroke(
                        width = max(1.5f * unit / INNER, 0.8f),
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round,
                    ),
                )
            }
        }
    }
}

/**
 * Stands in wherever the app asked for the system's spinning line, with the same
 * way of being called, so every place that loads shows [MorphLoader] instead.
 * The colour and thickness a caller passes are for the old line and are ignored:
 * the loader has its own look.
 */
@Composable
fun CircularProgressIndicator(
    modifier: Modifier = Modifier,
    @Suppress("UNUSED_PARAMETER") color: Color = Color.Unspecified,
    @Suppress("UNUSED_PARAMETER") strokeWidth: Dp = Dp.Unspecified,
    @Suppress("UNUSED_PARAMETER") trackColor: Color = Color.Unspecified,
    @Suppress("UNUSED_PARAMETER") strokeCap: StrokeCap = StrokeCap.Round,
) {
    MorphLoader(modifier = modifier)
}

// ---------------------------------------------------------------------------
// The shapes

private const val VIEW = 300f
private const val CENTRE = 150f
private const val RADIUS = 104f
private const val POINTS = 96

/** How long a change of form takes, and how long it rests before the next. */
private const val MORPH = 420L
private const val HOLD = 35L
private const val STEP = MORPH + HOLD

/** Radians a millisecond: the turn about its own centre. */
private const val SPIN_PER_MS = 0.0026

private const val INNER = 0.91f
private const val GLOW_ALPHA = 0.045f
private val GLOW_STEPS = floatArrayOf(26f, 18f, 11f, 5f)
private val GLOW = Color(0xFF79BAFF)

private fun smooth(x: Float): Float {
    val t = x.coerceIn(0f, 1f)
    return t * t * (3f - 2f * t)
}

/** How far out the edge is at angle [a], as a share of the radius; always rounded. */
private val PRESETS: List<(Double) -> Double> = listOf(
    { _ -> 1.0 },                                                   // round
    { a -> 1 + .035 * cos(4 * a) },                                 // soft rounded square
    { a -> 1 + .045 * cos(3 * a) },                                 // rounded triangle
    { a -> 1 + .040 * cos(5 * a) },                                 // rounded pentagon
    { a -> 1 + .038 * cos(6 * a) },                                 // rounded hexagon
    { a -> 1 + .032 * cos(8 * a) },                                 // rounded octagon
    { a -> 1 + .105 * cos(5 * a) },                                 // soft star / flower
    { a -> 1 + .085 * cos(6 * a) },                                 // six-lobe flower
    { a -> 1 + .075 * cos(8 * a) },                                 // eight-lobe flower
    { a -> 1 + .090 * cos(10 * a) },                                // scallop
    { a -> 1 + .055 * cos(12 * a) },                                // soft gear
    { a -> 1 + .070 * cos(4 * a + sin(2 * a) * .12) },              // clover
    { a -> 1 + .065 * sin(3 * a + .4) + .035 * cos(5 * a - .5) },   // organic
    { a -> 1 + .050 * sin(2 * a) + .045 * cos(7 * a + .3) },        // flowing blob
)

/** Each form as [POINTS] points round the centre, in the 300-unit square, x then y. */
private val FORMS: Array<FloatArray> = Array(PRESETS.size) { form ->
    val phase = form * .019
    FloatArray(POINTS * 2).also { out ->
        for (i in 0 until POINTS) {
            val a = 2.0 * PI * i / POINTS
            val radius = RADIUS * PRESETS[form](a + phase).coerceIn(.78, 1.16)
            out[i * 2] = (cos(a) * radius).toFloat()
            out[i * 2 + 1] = (sin(a) * radius).toFloat()
        }
    }
}

private val LOOP = STEP * PRESETS.size

/**
 * A closed curve through [p], smooth at every point (Catmull-Rom), into [path],
 * placed on [centre] at [unit] pixels to the unit.
 */
private fun curve(path: Path, p: FloatArray, centre: Offset, unit: Float) {
    path.rewind()
    fun x(i: Int) = centre.x + p[(((i % POINTS) + POINTS) % POINTS) * 2] * unit
    fun y(i: Int) = centre.y + p[(((i % POINTS) + POINTS) % POINTS) * 2 + 1] * unit
    path.moveTo(x(0), y(0))
    for (i in 0 until POINTS) {
        path.cubicTo(
            x(i) + (x(i + 1) - x(i - 1)) / 6f,
            y(i) + (y(i + 1) - y(i - 1)) / 6f,
            x(i + 1) - (x(i + 2) - x(i)) / 6f,
            y(i + 1) - (y(i + 2) - y(i)) / 6f,
            x(i + 1),
            y(i + 1),
        )
    }
    path.close()
}
